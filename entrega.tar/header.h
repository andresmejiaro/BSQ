/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amejia <amejia@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/22 23:59:04 by amejia            #+#    #+#             */
/*   Updated: 2022/11/23 00:11:55 by amejia           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H
# include "unistd.h"
# include "stdlib.h"
# include "fcntl.h"

int		evaluator_function_n(char c);
int		ft_str_is_numeric(char *str);
int		check_space(char c);
int		ft_atoi(char *str);
void	ft_delete_char(char *str);
char	*ft_strcat(char *s1, char *s2);
char	*ft_strcpy(char *dest, char *src);
int		evaluator_function(char c);
int		ft_str_is_printable(char *str);
int		ft_strlen(char *str);
char	*ft_strstr(char *s1, char *s2);
void	ft_putstr(char *str);
int		count_char(int fo);
char	**lines_to_map(char **lines, int n_lines, char *symbols);
char	*read_text_file2(int fo, int fsize);
char	*read_text_file(char *path);
int		count_lines(char *str);
char	**linefy(char *str, int *n_lines);
void	print_lines(char **lines, int n_lines);

#endif
